@extends('layouts.app')

@section('content')
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4 class="mb-0"><i class="fas fa-file-invoice me-2"></i> Order Invoice</h4>
                        <div>
                            <button onclick="window.print()" class="btn btn-light btn-sm">
                                <i class="fas fa-print me-1"></i> Print
                            </button>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h5>Order Information</h5>
                            <p><strong>Invoice #:</strong> INV-{{ str_pad($order->order_id, 6, '0', STR_PAD_LEFT) }}</p>
                            <p><strong>Order Date:</strong> {{ $order->created_at->format('F j, Y') }}</p>
                            <p><strong>Status:</strong> 
                                <span class="badge bg-primary text-capitalize">
                                    {{ str_replace('_', ' ', $order->order_status) }}
                                </span>
                            </p>
                        </div>
                        <div class="col-md-6 text-md-end">
                            <h5>Payment Information</h5>
                            <p><strong>Payment Status:</strong> 
                                <span class="badge {{ $order->payment_status === 'completed' ? 'bg-success' : 'bg-warning' }} text-capitalize">
                                    {{ $order->payment_status }}
                                </span>
                            </p>
                            <p><strong>Transaction ID:</strong> {{ $order->transaction_id }}</p>
                            <p><strong>Total Amount:</strong> ₹{{ number_format($order->total_amount, 2) }}</p>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h5>Billing Information</h5>
                            <p><strong>Customer ID:</strong> {{ str_pad($order->user_id, 6, '0', STR_PAD_LEFT) }}</p>
                            <p><strong>Customer Name:</strong> {{ Auth::user()->name }}</p>
                            <p><strong>Email:</strong> {{ Auth::user()->email }}</p>
                        </div>
                        <div class="col-md-6">
                            <h5>Shipping Information</h5>
                            @if($order->address)
                                <p><strong>Name:</strong> {{ $order->address->name }}</p>
                                <p><strong>Address:</strong> {{ $order->address->address_line1 }}, {{ $order->address->address_line2 }}</p>
                                <p><strong>City:</strong> {{ $order->address->city }}, {{ $order->address->state }} - {{ $order->address->zipcode }}</p>
                                <p><strong>Phone:</strong> {{ $order->address->phone }}</p>
                            @else
                                <p class="text-danger">Shipping address not found</p>
                            @endif
                        </div>
                    </div>

                    <div class="mb-4">
                        <h5>Order Items</h5>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead class="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Product</th>
                                        <th>Quantity</th>
                                        <th>Unit Price</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>
                                            @if($order->product)
                                                {{ $order->product->product_name }}
                                            @else
                                                Product not found
                                            @endif
                                        </td>
                                        <td>{{ $order->quantity }}</td>
                                        <td>₹{{ number_format($order->total_amount / $order->quantity, 2) }}</td>
                                        <td>₹{{ number_format($order->total_amount, 2) }}</td>
                                    </tr>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="4" class="text-end"><strong>Subtotal:</strong></td>
                                        <td>₹{{ number_format($order->total_amount, 2) }}</td>
                                    </tr>
                                    <tr>
                                        <td colspan="4" class="text-end"><strong>Shipping:</strong></td>
                                        <td>₹0.00</td>
                                    </tr>
                                    <tr>
                                        <td colspan="4" class="text-end"><strong>Total:</strong></td>
                                        <td>₹{{ number_format($order->total_amount, 2) }}</td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>

                    <div class="border-top pt-4 mt-4">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6>Thank you for your business!</h6>
                                <p class="text-muted">If you have any questions about this invoice, please contact our customer support.</p>
                            </div>
                            <div class="text-end">
                                <p class="mb-1"><strong>Order ID:</strong> #{{ $order->order_id }}</p>
                                <p class="mb-0"><strong>Invoice Date:</strong> {{ now()->format('F j, Y') }}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection