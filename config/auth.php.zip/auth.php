<?php

return [

    'defaults' => [
        'guard' => env('AUTH_GUARD', 'web'),
        'passwords' => env('AUTH_PASSWORD_BROKER', 'users'),
    ],

    'guards' => [
        'web' => [
            'driver' => 'session',
            'provider' => 'users',
        ],

        'Bibliophile' => [ // Capital B here
            'driver' => 'session',
            'provider' => 'bibliophiles',
        ],

        'admin' => [
            'driver' => 'session',
            'provider' => 'admins',
        ],
    ],

   'providers' => [
    'users' => [
        'driver' => 'eloquent', // change to eloquent for model-based access
        'model' => App\Models\Users::class, // point to your User model
    ],

        'sellers' => [
            'driver' => 'database',
            'table' => 'seller',
        ],

      'admins' => [
    'driver' => 'eloquent',
    'model' => App\Models\AdminUser::class,
],


        'bibliophiles' => [ // lowercase here is fine
            'driver' => 'eloquent',
            'model' => App\Models\Bibliophile::class,
        ],
    ],

    'passwords' => [
        'users' => [
            'provider' => 'users',
            'table' => env('AUTH_PASSWORD_RESET_TOKEN_TABLE', 'password_reset_tokens'),
            'expire' => 60,
            'throttle' => 60,
        ],

        'bibliophiles' => [
            'provider' => 'bibliophiles',
            'table' => env('AUTH_PASSWORD_RESET_TOKEN_TABLE', 'password_reset_tokens'),
            'expire' => 60,
            'throttle' => 60,
        ],
    ],

    'password_timeout' => env('AUTH_PASSWORD_TIMEOUT', 10800),

];
