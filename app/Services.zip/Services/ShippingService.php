<?php

namespace App\Services;

use App\Models\State;
use App\Models\Product;

class ShippingService
{
    public function calculateShippingCost($product, $stateName)
    {
        // Get the state shipping rules
        $state = State::where('name', $stateName)->first();

        if (!$state) {
            return 0; // or handle error appropriately
        }

        // Get product weight in grams
        $productWeight = $product->getWeightInGrams();

        if ($productWeight <= $state->base_weight) {
            return $state->base_cost;
        }

        // Calculate additional weight units
        $additionalWeight = $productWeight - $state->base_weight;
        $additionalUnits = ceil($additionalWeight / $state->additional_weight_unit);

        return $state->base_cost + ($additionalUnits * $state->additional_cost_per_unit);
    }
}
