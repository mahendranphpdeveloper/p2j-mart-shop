@extends('layouts.app')

@section('content')
<div class="container py-4">
    <div class="row">
        <div class="col-12">
            <h2 class="mb-4">Your Wishlist</h2>

            @if($wishlistItems->isEmpty())
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Your wishlist is empty. 
                    <a href="{{ route('home') }}" class="alert-link">Continue shopping</a>
                </div>
            @else
                <div class="section py-4">
                    <div class="custom-container1">
                        <div class="row">
                            <div class="col-12">
                                <div class="table-responsive shop_cart_table">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th class="product-thumbnail">&nbsp;</th>
                                                <th class="product-name">Product</th>
                                                <th class="product-price">Price</th>
                                                <th class="product-remove">Remove</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($wishlistItems as $item)
                                                <tr>
                                                    <td class="product-thumbnail">
                                                        <a href="#">
                                                            @if($item->product && $item->product->productImage && $item->product->productImage->web_image_1)
                                                                <img src="{{ asset('uploads/products/' . $item->product->productImage->web_image_1) }}" alt="{{ $item->product->name }}">
                                                            @else
                                                                <img src="{{ asset('assets/images/placeholder.jpg') }}" alt="placeholder">
                                                            @endif
                                                        </a>
                                                    </td>
                                                    <td class="product-name" data-title="Product">
                                                    <strong>{{ $item->product->product_name }}</strong><br/>
                                                    </td>
                                                    <td class="product-price" data-title="Price">
                                                    ₹{{ number_format($item->product->price, 2) }}
                                                    </td>
                                                    <td class="product-remove" data-title="Remove">
                                                        <a href="#" class="remove-from-wishlist" data-product-id="{{ $item->product_id }}">
                                                            <i class="fa fa-times"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                <a href="{{ route('home') }}" class="btn btn-fill-out mt-4">Continue Shopping</a>
                            </div>
                        </div>
                    </div>
                </div>
            @endif
        </div>
    </div>
</div>


<script>
$(document).ready(function() {
    console.log("Wishlist page JS initialized");

    // Remove Item From Wishlist
    $(document).on('click', '.remove-from-wishlist', function(e) {
        e.preventDefault();
        const productId = $(this).data('product-id');
        console.log("Removing product with ID:", productId);  // Debugging log

        if (!confirm('Are you sure you want to remove this item from your wishlist?')) return;

        $.ajax({
            url: '{{ route("wishlist.remove") }}',
            method: 'POST',
            data: {
                product_id: productId,  // Change to product_id
                _token: '{{ csrf_token() }}'
            },
            success: function(response) {
                console.log("Response from server:", response);  // Debugging log
                if (response.success) {
                    window.location.reload();
                } else {
                    alert('Failed to remove item: ' + (response.message || 'Unknown error'));
                }
            },
            error: function(xhr) {
                console.log("Error details:", xhr);  // Debugging log
                alert('Error removing item: ' + (xhr.responseJSON?.message || 'Unknown error'));
            }
        });
    });
});
</script>

@endsection


