@extends('layouts.app')

@section('content')
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">

            <!-- Toast Container -->
            <div id="toastContainer" class="position-fixed bottom-0 end-0 p-3" style="z-index: 9999;"></div>

            <!-- Show toast if session success -->
            @if(session('success'))
                <script>
                    window.addEventListener('DOMContentLoaded', () => {
                        showToast('success', '{{ session("success") }}');
                    });
                </script>
            @endif

            <!-- Confirmation -->
            <div class="card mb-4 shadow-lg">
                <div class="card-header bg-success text-white">
                    <h4 class="mb-0"><i class="fas fa-check-circle me-2"></i> Order Confirmation</h4>
                </div>
                <div class="card-body">
                    <p class="mb-2">Your order <strong>#{{ $order->order_id }}</strong> was placed successfully.</p>
                </div>
            </div>

            <!-- Orders List (One by One) -->
            @foreach($allOrders->sortByDesc('created_at') as $userOrder)
            <div class="card mb-4 shadow-sm border rounded">
                <div class="row g-0">
                    <div class="col-md-4">
                    <img src="{{ asset('uploads/product_images/' . ($userOrder->product->productImage->web_image_1 ?? 'default.jpg')) }}" alt="Product Image" class="img-fluid rounded-start">


                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <div class="d-flex justify-content-between mb-2">
                                <h5 class="card-title">{{ $userOrder->product->product_name ?? 'Product Unavailable' }}</h5>
                                <span class="badge 
                                    @if($userOrder->order_status === 'processing') bg-info
                                    @elseif($userOrder->order_status === 'shipped') bg-primary
                                    @elseif($userOrder->order_status === 'delivered') bg-success
                                    @elseif($userOrder->order_status === 'cancelled') bg-secondary
                                    @elseif($userOrder->order_status === 'returned') bg-warning
                                    @endif text-capitalize">
                                    {{ str_replace('_', ' ', $userOrder->order_status) }}
                                </span>
                            </div>
                            <p class="card-text text-muted mb-2">
    <strong>Order ID:</strong> #{{ $userOrder->order_id }}<br>
    <strong>Date:</strong> {{ $userOrder->created_at->format('M d, Y') }}<br>
    <strong>Quantity:</strong> {{ $userOrder->quantity }}<br>
    <strong>Total:</strong> ₹{{ number_format($userOrder->total_amount, 2) }}
</p>

@if($userOrder->tracking_id || $userOrder->tracking_link)
    <p class="card-text text-success mb-2">
        @if($userOrder->tracking_id)
            <strong>Tracking ID:</strong> {{ $userOrder->tracking_id }}<br>
        @endif
        @if($userOrder->tracking_link)
            <strong>Track Here:</strong> 
            <a href="{{ $userOrder->tracking_link }}" target="_blank" class="text-decoration-underline">
                {{ $userOrder->tracking_link }}
            </a>
        @endif
    </p>
@endif

                            <div class="d-flex justify-content-between mt-3">
                            <a href="{{ route('orders.invoice', $userOrder->order_id) }}" class="btn btn-sm btn-outline-secondary">
    <i class="fas fa-file-invoice"></i> Invoice
</a>

@if(in_array($userOrder->order_status, ['processing', 'pending']))
    <button class="btn btn-sm btn-outline-danger cancel-order-btn" data-order-id="{{ $userOrder->order_id }}">
        <i class="fas fa-times"></i> Cancel Order
    </button>
@endif

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach

        </div>
    </div>
</div>
@endsection

<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.cancel-order-btn').forEach(button => {
        button.addEventListener('click', async function () {
            const orderId = this.dataset.orderId;

            if (!confirm("Are you sure you want to cancel this order?")) {
                return;
            }

            const url = cancelOrderUrl.replace(':id', orderId); // 👈 Replace :id with actual ID
            console.log('🚀 Cancel URL:', url);

            try {
                const response = await fetch(url, {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                });

                const result = await response.json();
                console.log('✅ Server response:', result);

                if (result.success) {
                    showToast('success', result.message);
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast('error', result.error);
                }
            } catch (error) {
                console.error('❌ Fetch error:', error);
                showToast('error', 'Network error occurred. Please try again.');
            }
        });
    });

    function showToast(type, message) {
        const toastContainer = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white bg-${type} border-0 show`;
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        toast.setAttribute('aria-atomic', 'true');

        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">${message}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `;

        toastContainer.appendChild(toast);
        setTimeout(() => toast.remove(), 5000);
    }
});

</script>
